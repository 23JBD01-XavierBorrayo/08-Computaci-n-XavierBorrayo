/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package FormPedidosYa;

import javax.swing.table.DefaultTableModel;

/**
 *
 * @author jnadi
 */
public class PedidosYa extends javax.swing.JFrame {
    
    DefaultTableModel modelo = new DefaultTableModel();

    String [] columnas = {"Código", "Producto", "Precio", "Cantidad", "Total"};
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(PedidosYa.class.getName());

    /**

     */
    public PedidosYa() {
        initComponents();
        this.setTitle("Productos Tabla");
        this.setLocationRelativeTo(null); 
        this.setResizable(false); 
    

    modelo.setColumnIdentifiers(columnas);
    tabla.setModel(modelo); // Asegúrate de que tu JTable se llame tablaProductos
    }
        
    

    /**

     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        codigotext = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        codigo0 = new javax.swing.JTextField();
        nombre0 = new javax.swing.JTextField();
        cantidad0 = new javax.swing.JTextField();
        precio0 = new javax.swing.JTextField();
        datos = new javax.swing.JLabel();
        guardar = new javax.swing.JButton();
        eliminar = new javax.swing.JButton();
        modificar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        tabla.setFont(new java.awt.Font("balatro", 0, 12)); // NOI18N
        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tabla);

        jLabel1.setFont(new java.awt.Font("balatro", 0, 18)); // NOI18N
        jLabel1.setText("NOMBRE");

        jLabel2.setFont(new java.awt.Font("balatro", 0, 18)); // NOI18N
        jLabel2.setText("PRECIO");

        codigotext.setFont(new java.awt.Font("balatro", 0, 18)); // NOI18N
        codigotext.setText("CÓDIGO");

        jLabel4.setFont(new java.awt.Font("balatro", 0, 18)); // NOI18N
        jLabel4.setText("CANTIDAD");

        codigo0.setFont(new java.awt.Font("balatro", 0, 12)); // NOI18N

        nombre0.setFont(new java.awt.Font("balatro", 0, 12)); // NOI18N

        cantidad0.setFont(new java.awt.Font("balatro", 0, 12)); // NOI18N

        precio0.setFont(new java.awt.Font("balatro", 0, 12)); // NOI18N

        datos.setFont(new java.awt.Font("balatro", 0, 8)); // NOI18N
        datos.setText("José Xavier Borrayo de León | 4to Bach. | Colegio Salesiano Don Bosco");

        guardar.setFont(new java.awt.Font("balatro", 0, 14)); // NOI18N
        guardar.setText("GUARDAR");
        guardar.addActionListener(this::guardarActionPerformed);

        eliminar.setFont(new java.awt.Font("balatro", 0, 14)); // NOI18N
        eliminar.setText("ELIMINAR");
        eliminar.addActionListener(this::eliminarActionPerformed);

        modificar.setFont(new java.awt.Font("balatro", 0, 14)); // NOI18N
        modificar.setText("MODIFICAR");
        modificar.addActionListener(this::modificarActionPerformed);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 375, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(datos, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(18, 18, 18)
                                .addComponent(cantidad0))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(codigotext)
                                    .addComponent(jLabel1)
                                    .addComponent(jLabel2))
                                .addGap(30, 30, 30)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(codigo0)
                                    .addComponent(nombre0)
                                    .addComponent(precio0)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(guardar)
                                .addGap(28, 28, 28)
                                .addComponent(modificar)
                                .addGap(33, 33, 33)
                                .addComponent(eliminar)))
                        .addGap(0, 83, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(datos)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(guardar)
                            .addComponent(eliminar)
                            .addComponent(modificar))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(codigotext)
                            .addComponent(codigo0, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(12, 12, 12)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(nombre0, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(precio0, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(cantidad0, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void guardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_guardarActionPerformed
        // TODO add your handling code here:
        try {
        String codigo = codigo0.getText();
        String nombre = nombre0.getText();
        
     
        double precio = Double.parseDouble(precio0.getText());
        int cantidad = Integer.parseInt(cantidad0.getText());
        
   
        double total = precio * cantidad;
        
        // Insertamos al modelo de la tabla
        modelo.addRow(new Object[]{
            codigo,
            nombre,
            precio,
            cantidad,
            total
        });
        
  
        codigo0.setText("");
        nombre0.setText("");
        precio0.setText("");
        cantidad0.setText("");
        codigo0.requestFocus(); 
        
    } catch(NumberFormatException e) {
        System.out.println("Ingresa números válidos en Precio y Cantidad");
    }

        
    }//GEN-LAST:event_guardarActionPerformed

    private void eliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminarActionPerformed
        // TODO add your handling code here:
        int filaSeleccionada = tabla.getSelectedRow();
    
  
    if (filaSeleccionada >= 0) {
        modelo.removeRow(filaSeleccionada);
    } else {
        System.out.println("Selecciona una fila para eliminar.");
    }

    }//GEN-LAST:event_eliminarActionPerformed

    private void modificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modificarActionPerformed
        // TODO add your handling code here:
        int filaSeleccionada = tabla.getSelectedRow();
    
    if (filaSeleccionada >= 0) {
        try {
            double precio = Double.parseDouble(precio0.getText());
            int cantidad = Integer.parseInt(cantidad0.getText());
            double total = precio * cantidad;
            
            // setValueAt actualiza un dato en (Dato, Fila, Columna)
            modelo.setValueAt(codigo0.getText(), filaSeleccionada, 0);
            modelo.setValueAt(nombre0.getText(), filaSeleccionada, 1);
            modelo.setValueAt(precio, filaSeleccionada, 2);
            modelo.setValueAt(cantidad, filaSeleccionada, 3);
            modelo.setValueAt(total, filaSeleccionada, 4);
            
        } catch(NumberFormatException e) {
            System.out.println("Revisa los números.");
        }
    }

    }//GEN-LAST:event_modificarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new PedidosYa().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField cantidad0;
    private javax.swing.JTextField codigo0;
    private javax.swing.JLabel codigotext;
    private javax.swing.JLabel datos;
    private javax.swing.JButton eliminar;
    private javax.swing.JButton guardar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton modificar;
    private javax.swing.JTextField nombre0;
    private javax.swing.JTextField precio0;
    private javax.swing.JTable tabla;
    // End of variables declaration//GEN-END:variables
}
