/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.calculadorabonita;

/**
 *
 * @author LABORATORIO
 */
public class calculadoraXavierBorayo08 {

    public static void main(String[] args) {
        jrfmcalc v1=new jrfmcalc();
        v1.setVisible(true);
    }
}
