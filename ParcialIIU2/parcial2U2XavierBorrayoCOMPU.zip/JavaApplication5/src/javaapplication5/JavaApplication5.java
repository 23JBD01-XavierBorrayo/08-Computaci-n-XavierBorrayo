/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication5;

/**
 *
 * @author jnadi
 */
public class JavaApplication5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String pass = javax.swing.JOptionPane.showInputDialog(null, "Ingrese la contraseña:");
        if (pass != null && pass.equals("123")) {
            javax.swing.JOptionPane.showMessageDialog(null, "Bienvenido: Gatunito");
              new CalcuDescuentos().setVisible(true);

        }
        else {
            javax.swing.JOptionPane.showMessageDialog(null, "Error: Acceso denegado");
            System.exit(0);
        }
    }
    
}
