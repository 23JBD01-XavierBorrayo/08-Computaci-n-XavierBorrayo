/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.calculadorabasicairl;

/**
 *
 * @author LABORATORIO
 */
public class CalculadorabasicaIRL {

    public static void main(String[] args) {
        calc c1 = new calc();
        c1.setVisible(true);
    }
}
